using UnityEngine;
using System.Collections;

public class quit : MonoBehaviour {

	public void quitter()
    {
        Application.Quit();
    }
}
